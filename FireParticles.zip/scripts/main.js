import { world } from "@minecraft/server";
import { system } from "@minecraft/server";

let active = false;

world.afterEvents.inputButtonSignal.subscribe(ev => {
  if (ev.button === "key.keyboard.f" && ev.state) {
    active = !active;
    world.say(`FireParticles: ${active ? "ON" : "OFF"}`);
  }
});

system.runInterval(() => {
  if (!active) return;
  for (const pl of world.getPlayers()) {
    const pos = pl.location;
    world.sendCommand(`particle flame "${pl.nameTag}" ${pos.x} ${pos.y + 1} ${pos.z} 0 0 0 0 1 force`);
  }
}, 20);
